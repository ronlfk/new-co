import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Smartphone, Users, Zap, Mail, Link } from "lucide-react";
import { Link as RouterLink } from "react-router-dom";

const Index = () => {
  const handleContactUs = () => {
    window.location.href = "mailto:lemonanagamedev@gmail.com";
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100">
      {/* Header */}
      <header className="bg-white shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <div className="flex justify-between items-center">
            <h1 className="text-3xl font-bold text-indigo-600">MillionApps</h1>
            <nav className="hidden md:flex space-x-6">
              <RouterLink to="/privacy" className="text-gray-600 hover:text-indigo-600 transition-colors">
                Privacy Policy
              </RouterLink>
              <RouterLink to="/terms" className="text-gray-600 hover:text-indigo-600 transition-colors">
                Terms of Service
              </RouterLink>
              <Button onClick={handleContactUs} variant="outline" size="sm">
                <Mail className="w-4 h-4 mr-2" />
                Contact Us
              </Button>
            </nav>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20">
        <div className="text-center">
          <h2 className="text-5xl font-bold text-gray-900 mb-6">
            Building Tools That
            <span className="text-indigo-600"> Help People</span>
          </h2>
          <p className="text-xl text-gray-600 mb-8 max-w-3xl mx-auto">
            At MillionApps, we specialize in creating innovative tool applications that simplify 
            everyday tasks and empower users to achieve more. Our mission is to build software 
            that makes a real difference in people's lives.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button onClick={handleContactUs} size="lg" className="bg-indigo-600 hover:bg-indigo-700">
              <Mail className="w-5 h-5 mr-2" />
              Connect With Us
            </Button>
            <RouterLink to="/privacy">
              <Button variant="outline" size="lg">
                Privacy Policy
              </Button>
            </RouterLink>
            <RouterLink to="/terms">
              <Button variant="outline" size="lg">
                Terms of Service
              </Button>
            </RouterLink>
            <RouterLink to="/app-ads.txt">
              <Button variant="outline" size="lg">
                <Link className="w-5 h-5 mr-2" />
                App Ads
              </Button>
            </RouterLink>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="grid md:grid-cols-3 gap-8">
          <Card className="text-center hover:shadow-lg transition-shadow">
            <CardHeader>
              <Smartphone className="w-12 h-12 text-indigo-600 mx-auto mb-4" />
              <CardTitle>Tool Applications</CardTitle>
            </CardHeader>
            <CardContent>
              <CardDescription>
                We create practical applications that solve real-world problems and enhance productivity.
              </CardDescription>
            </CardContent>
          </Card>

          <Card className="text-center hover:shadow-lg transition-shadow">
            <CardHeader>
              <Users className="w-12 h-12 text-indigo-600 mx-auto mb-4" />
              <CardTitle>User-Focused</CardTitle>
            </CardHeader>
            <CardContent>
              <CardDescription>
                Every app we build is designed with the user in mind, ensuring intuitive and helpful experiences.
              </CardDescription>
            </CardContent>
          </Card>

          <Card className="text-center hover:shadow-lg transition-shadow">
            <CardHeader>
              <Zap className="w-12 h-12 text-indigo-600 mx-auto mb-4" />
              <CardTitle>Efficient Solutions</CardTitle>
            </CardHeader>
            <CardContent>
              <CardDescription>
                We deliver fast, reliable, and efficient solutions that help people accomplish their goals.
              </CardDescription>
            </CardContent>
          </Card>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-900 text-white py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <h3 className="text-2xl font-bold mb-4">MillionApps</h3>
            <p className="text-gray-400 mb-6">Building tools that help people achieve more.</p>
            <div className="flex justify-center space-x-6">
              <Link to="/privacy" className="text-gray-400 hover:text-white transition-colors">
                Privacy Policy
              </Link>
              <Link to="/terms" className="text-gray-400 hover:text-white transition-colors">
                Terms of Service
              </Link>
              <button 
                onClick={handleContactUs}
                className="text-gray-400 hover:text-white transition-colors"
              >
                Contact: lemonanagamedev@gmail.com
              </button>
            </div>
            <p className="text-gray-500 text-sm mt-6">
              © 2024 MillionApps. All rights reserved.
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default Index;
