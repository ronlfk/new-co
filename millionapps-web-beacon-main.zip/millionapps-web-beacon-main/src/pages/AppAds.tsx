
import { useEffect } from 'react';

const AppAds = () => {
  useEffect(() => {
    // Redirect to the external app-ads.txt URL
    window.location.href = 'https://millionappss.blogspot.com/ads.txt';
  }, []);

  return null;
};

export default AppAds;
