
import { useEffect } from 'react';

const NotFound = () => {
  useEffect(() => {
    // Redirect to app-ads.txt when a 404 occurs
    window.location.href = '/app-ads.txt';
  }, []);

  return null;
};

export default NotFound;
