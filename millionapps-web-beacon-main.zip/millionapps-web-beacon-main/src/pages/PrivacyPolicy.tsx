
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Link } from "react-router-dom";
import { ArrowLeft } from "lucide-react";

const PrivacyPolicy = () => {
  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <div className="flex justify-between items-center">
            <Link to="/" className="text-3xl font-bold text-indigo-600">MillionApps</Link>
            <Link to="/">
              <Button variant="outline" size="sm">
                <ArrowLeft className="w-4 h-4 mr-2" />
                Back to Home
              </Button>
            </Link>
          </div>
        </div>
      </header>

      {/* Content */}
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <Card>
          <CardHeader>
            <CardTitle className="text-3xl">Privacy Policy</CardTitle>
            <p className="text-gray-600">Last updated: {new Date().toLocaleDateString()}</p>
          </CardHeader>
          <CardContent className="prose max-w-none">
            <h2 className="text-2xl font-semibold mb-4">Information We Collect</h2>
            <p className="mb-4">
              At MillionApps, we are committed to protecting your privacy. This Privacy Policy explains how we collect, 
              use, and safeguard your information when you use our applications and services.
            </p>

            <h3 className="text-xl font-semibold mb-3">Personal Information</h3>
            <p className="mb-4">
              We may collect personal information that you voluntarily provide to us when you:
            </p>
            <ul className="list-disc pl-6 mb-4">
              <li>Contact us via email</li>
              <li>Use our applications</li>
              <li>Subscribe to our services</li>
              <li>Provide feedback or suggestions</li>
            </ul>

            <h3 className="text-xl font-semibold mb-3">Usage Data</h3>
            <p className="mb-4">
              We may automatically collect certain information about your device and usage patterns, including:
            </p>
            <ul className="list-disc pl-6 mb-4">
              <li>Device information and operating system</li>
              <li>Application usage statistics</li>
              <li>Crash reports and performance data</li>
            </ul>

            <h2 className="text-2xl font-semibold mb-4 mt-8">How We Use Your Information</h2>
            <p className="mb-4">We use the collected information to:</p>
            <ul className="list-disc pl-6 mb-4">
              <li>Provide and maintain our applications</li>
              <li>Improve user experience</li>
              <li>Respond to customer support requests</li>
              <li>Send important updates and notifications</li>
              <li>Analyze usage patterns to enhance our services</li>
            </ul>

            <h2 className="text-2xl font-semibold mb-4 mt-8">Data Security</h2>
            <p className="mb-4">
              We implement appropriate security measures to protect your personal information against unauthorized 
              access, alteration, disclosure, or destruction. However, no method of transmission over the internet 
              or electronic storage is 100% secure.
            </p>

            <h2 className="text-2xl font-semibold mb-4 mt-8">Third-Party Services</h2>
            <p className="mb-4">
              Our applications may contain links to third-party websites or services. We are not responsible for 
              the privacy practices of these external sites.
            </p>

            <h2 className="text-2xl font-semibold mb-4 mt-8">Contact Us</h2>
            <p className="mb-4">
              If you have any questions about this Privacy Policy, please contact us at:
            </p>
            <p className="font-semibold">lemonanagamedev@gmail.com</p>

            <h2 className="text-2xl font-semibold mb-4 mt-8">Changes to This Policy</h2>
            <p className="mb-4">
              We may update this Privacy Policy from time to time. We will notify you of any changes by posting 
              the new Privacy Policy on this page and updating the "Last updated" date.
            </p>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default PrivacyPolicy;
